<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
        

 <div class="cont">
    <header>
        <h2>
        
 <a href="https://www.facebook.com/odot.perseka/"> <span style="color: hsl(123, 74%, 9%)"> odot </span> perseka</a>

        </h2>
        <ul>
            <li><a href="https://www.facebook.com/odot.perseka/">HOME   </a>   </li>
            <li><a href="#"></a>ABOUT</li>
            <li><a href="#"></a>SKILLS</li>
            <li><a href="#"></a>MY WORKS</li>
            <li><a href="#"></a>CONTACT</li>
        </ul>
    </header>
    <section>
    </section>

    
    </div>
    
</body>
</html>
